def main():
    name = input("What's your name? ")
    hello(name)

def hello(to):
    print("Hello,", to, "!\n")

main()
