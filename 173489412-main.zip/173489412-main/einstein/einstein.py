c = 300000000
masskg = int(input("Please enter a mass in kg: "))
e = masskg * (c**2)
print("E: ", e)
