userin = (input("Please type something: "))
print(userin.lower())
