userstr = input("Please enter some words: ")
print(userstr.replace(" ", "..."))



